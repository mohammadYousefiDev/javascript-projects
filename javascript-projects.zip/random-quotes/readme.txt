Demo:
https://mohammadyousefi.com/javascript-projects/random-quotes/

We want to show random qoutes when button is clicked
1. Create a button for method fireing
2. Create a qoute box with default qoute
3. Create a base method to change qoutes
4. Create a qoutes array with multiple qoute
5. Get random qoute with Math methods
6. Replace and display random qoute in qoute box