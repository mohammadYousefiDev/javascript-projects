Demo:
https://mohammadyousefi.com/javascript-projects/counter/

We want to increase or decrease a number
1. Create number box to display default number(zero is default)
2. Create an increase & decrease button
3. Create base increase method
4. Get current number of box
5. Increase one unit to it
6. check number, if its positive, set green color and if its zero, set dark color
3. Create base decrease method
4. Get current number of box
5. decrease one unit to it
6. check number, if its negative, set red color and if its zero, set dark color