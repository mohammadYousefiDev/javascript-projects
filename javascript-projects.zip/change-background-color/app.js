function changeBackgroundColor() {
  const color = document.getElementById('colorPicker').value;
  document.body.style.backgroundColor = color;
}