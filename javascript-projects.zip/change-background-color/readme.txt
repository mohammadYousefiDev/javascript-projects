We want to change page background color
1. create a color input to select background color
2. create a button to fire change background color method and do it
3. create change background color method in js file
4. get color picker input value
5. set background color for body dom element