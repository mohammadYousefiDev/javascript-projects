Demo:
https://mohammadyousefi.com/javascript-projects/pass-the-message/

We want to pass entered message in message box
1. Create input text for message
2. Create a button to click event handling
3. Create message box to display entered message after click on button
4. Create base method for passing message
5. Get entered message
6. Check message is not empty (display an alert if message is empty)
7. Display message on message box